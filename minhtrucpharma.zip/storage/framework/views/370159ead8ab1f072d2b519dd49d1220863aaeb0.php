<!DOCTYPE html>

<!--[if IE 7 ]>  <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>  <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>  <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!-- Meta -->
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo $__env->yieldContent('title'); ?> | Minh Trúc Pharma</title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
        <meta name="author" content="Web Đẹp Nha Trang" />
        <meta http-equiv="content-language" content="<?php echo e(app()->getLocale()); ?>" />
        <meta name="robots" content="index, follow">
        <meta name="revisit-after" content="3 days">
        <meta name="geo.region" content="VN-34" />
        <meta name="geo.position" content="12.218285;109.188664" />
        <meta name="ICBM" content="12.218285, 109.188664" />
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- FB Open Graph Tags -->
        <meta property="fb:app_id"        content="xxxxxxxxxxxxxx" />
        <meta property="og:url"           content="<?php echo $__env->yieldContent('fb_url'); ?>" />
        <meta property="og:type"          content="<?php echo $__env->yieldContent('fb_type'); ?>" />
        <meta property="og:title"         content="<?php echo $__env->yieldContent('fb_title'); ?>" />
        <meta property="og:description"   content="<?php echo $__env->yieldContent('fb_des'); ?>" />
        <meta property="og:image"         content="<?php echo $__env->yieldContent('fb_img'); ?>" />
   

        <link rel="shortcut icon" type="image/png" href="">
        <!-- Place favicon.ico in the root directory -->

		<!-- all css here -->
        <?php echo $__env->make('theme-default.partials.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->yieldContent('css'); ?>

        <!-- Google Analytics gtag js -->
        <?php echo $__env->make('theme-default.google.analytics', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body id="bg">
        <!-- Facebook SDK js -->
        <?php echo $__env->make('theme-default.facebook.facebook-sdk', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('theme-default.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('theme-default.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('theme-default.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('script'); ?>

    </body>
</html>