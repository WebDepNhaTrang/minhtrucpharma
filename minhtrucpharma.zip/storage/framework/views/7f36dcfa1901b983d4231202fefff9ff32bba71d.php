<?php $__env->startSection('title', 'Trang Chủ'); ?>
<?php $__env->startSection('description', setting('site.description')); ?>

<?php $__env->startSection('fb_url', route('frontend.pages.home')); ?>
<?php $__env->startSection('fb_type', 'website'); ?>
<?php $__env->startSection('fb_title', 'Trang Chủ - Minh Trúc Pharma'); ?>
<?php $__env->startSection('fb_des', setting('site.description')); ?>
<?php $__env->startSection('fb_img', ''); ?>

<?php $__env->startSection('content'); ?>
	<!-- Insert content here -->
    <!-- Content -->
    <div class="page-content">
        <!-- Slider -->
        <?php echo $__env->make('theme-default.partials.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Slider END -->
        <!-- About Company -->
        <div class="section-full content-inner bg-white">
            <div class="container">
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-7">
                            <h3 class="h3 text-uppercase">Về<span class="text-primary"> Chúng Tôi</span></h3>
                            <?php echo setting('about.st_about_content'); ?>

                        </div>
                        <div class="col-md-5">
                            <div class="dez-thum disnone-sm"><img src="<?php echo e(Voyager::image(setting('about.st_about_image'))); ?>" alt="Minh Trúc Pharma"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Company END -->
		<!-- Why Choose Us  -->
        <div class="section-full bg-img-fix content-inner overlay-primary-dark text-white" style="background-image:url(<?php echo e(asset('images/background/bg9.jpg')); ?>);">
            <div class="container">
                <div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="counter-style-1 m-b30">
							<div class="">
								<i class="icon flaticon-bar-chart text-white"></i>
								<span class="counter">7652</span>
							</div>
							<span class="counter-text">Khách Hàng</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="counter-style-1 m-b30">
							<div class="">
								<i class="icon flaticon-social text-white"></i>
								<span class="counter">4562</span>
							</div>
							<span class="counter-text">Đối Tác</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="counter-style-1 m-b30">
							<div class="">
								<i class="icon flaticon-file text-white"></i>
								<span class="counter">3569</span>
							</div>
							<span class="counter-text">Sản Phẩm</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="counter-style-1 m-b30">
							<div class="">
								<i class="icon flaticon-pencil text-white"></i>
								<span class="counter">2089</span>
							</div>
							<span class="counter-text">Giải Thưởng</span>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!-- Why Choose Us END -->
		<!-- Product -->
		<?php
			$products = getAllProducts('*', 'created_at', 'asc');
		?>
        <div class="section-full bg-white content-inner">
            <div class="container">
                <div class="section-head text-center ">
                    <h3 class="h3 text-uppercase"><span class="text-primary">Sản Phẩm</span> Tiêu Biểu</h3>
					<p><?php echo e(setting('product.description')); ?></p>
				</div>
				<?php if( $products->count() > 0 ): ?>
				<div class="container">
					<div class="row">
						<div class="col-md-3"></div>
						<?php $count = 0; ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if( $count < 2 ): ?>
								<div class="col-md-3 col-sm-6 m-b30">
									<div class="dez-box p-a20 border-1 bg-gray">
										<div class="dez-thum-bx dez-img-overlay1 dez-img-effect zoom"> <img src="<?php echo e(Voyager::image($v->image)); ?>" alt="<?php echo e($v->name); ?>">
											<div class="overlay-bx">
												<div class="overlay-icon"> <a href="<?php echo e(route('frontend.pages.product-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>"> <i class="fa fa-search icon-bx-xs"></i> </div>
											</div>
										</div>
										<div class="dez-info p-t20 text-center">
											<h4 class="dez-title m-t0 text-uppercase"><a href="<?php echo e(route('frontend.pages.product-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>"><?php echo e($v->name); ?></a></h4>
											<h2 class="m-b0"><?php echo e(number_format($v->price, 0, '', '.')); ?> VNĐ</h2>
											<a href="<?php echo e(route('frontend.pages.product-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>" class="site-button m-t15">Xem Chi Tiết</a> </div>
									</div>
								</div>
							<?php endif; ?>
							<?php $count++ ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3"></div>
					</div>
				</div>
				<?php endif; ?>
            </div>
        </div>
        <!-- Product END -->
        <!-- Our Project -->
        <div class="section-full bg-img-fix overlay-primary-dark content-inner-1 dez-support" style="background-image:url(images/background/bg9.jpg);">
            <div class="container">
                <div class="row">
					<div class="col-md-12 text-center text-white ">
						<h2 class="m-b15 m-t0">Chúng tôi hỗ trợ khách hàng 24/7</h2>
						<h3 class="m-t0 m-b20">Xin vui lòng liên hệ với chúng tôi theo số <?php echo e(setting('contact.phone')); ?></h3>
						<a href="<?php echo e(route('frontend.pages.contact')); ?>" class="site-button white radius-sm">Liên Hệ</a>
					</div>
			   </div>
            </div>
        </div>
		<!-- Our Project END -->
		<!-- Latest Blog -->
		<div class="section-full bg-white content-inner">
            <div class="container">
                <div class="section-head text-center ">
                    <h3 class="h3 text-uppercase">Hoạt Động <span class="text-primary">Nổi Bật</span></h3>
                    <p><?php echo e(setting('news.description')); ?></p>
				</div>
				<?php
					$posts = getPostByCategory('*', 1, 'created_at', 'desc', setting('news.paginate'));
				?>
				<?php if($posts->count()>0): ?>
                <div class="section-content owl-none">
                    <div class="blog-carousel">
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
							<div class="dez-box">
								<div class="dez-media"> 
									<a href="<?php echo e(route('frontend.pages.news-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>"><img src="<?php echo e(Voyager::image($v->image)); ?>" alt="<?php echo e($v->title); ?>"></a> 
								</div>
								<div class="dez-info p-a20 border-1">
									<div class="dez-post-meta ">
                                        <ul>
                                            <li class=""> <i class="fa fa-calendar"></i><strong><?php echo e($v->created_at->format('d-m-Y')); ?></strong></li>
                                            <li class="post-author"><i class="fa fa-user"></i>Đăng bởi <a href="#">Minh Trúc Pharma</a> </li>
                                        </ul>
                                    </div>
									<h4 class="dez-title m-t15"><a href="<?php echo e(route('frontend.pages.news-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>"><?php echo e($v->title); ?></a></h4>
									<p class="m-b15 excerpt"><?php echo e(shorten_text($v->excerpt, 200, '...', true)); ?></p>
									<a href="<?php echo e(route('frontend.pages.news-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>" class="site-button-link black">Xem thêm <i class="fa fa-long-arrow-right"></i></a> 
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
				</div>
				<?php endif; ?>
            </div>
        </div>
        <!-- Latest Blog END -->
		<!-- Testimoniay -->
		<?php
			$testimonials = getAllTestimonials('*', 'created_at', 'asc')
		?>
		<?php if( $testimonials->count() > 0 ): ?>
		<div class="section-full owl-dots-style bg-img-fix md-testimonial"  style="background-image:url(<?php echo e(asset('images/background/bg3.jpg')); ?>); background-size:cover;">
			<div class="container-fluid p-a0">
				<div class="section-content col-md-6 overlay-primary-dark content-inner-1 bg-img-fix " style="background-image:url(images/background/bg9.jpg);">
					<div class="testimonial-six relative z-index2">
						<?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="item">
							<div class="testimonial-1 testimonial-bg">
								<div class="testimonial-pic quote-left radius shadow"><img src="<?php echo e(Voyager::image($v->avatar)); ?>" width="100" height="100" alt="testimonial"></div>
								<div class="testimonial-text">
									<?php echo $v->content; ?>

								</div>
								<div class="testimonial-detail"> <strong class="testimonial-name"><?php echo e($v->name); ?></strong> <span class="testimonial-position"><?php echo e($v->job); ?></span> </div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<!-- Testimoniay END -->
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Insert script here -->
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('theme-default.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>