Bạn đã nhận được một tin nhắn từ : <?php echo e($contact['fullname']); ?>


<?php if(isset($contact['fullname'])): ?> 
<p>
Tên: <?php echo e($contact['fullname']); ?>

</p>
<?php endif; ?> 

<?php if(isset($contact['email'])): ?> 
<p>
Email: <?php echo e($contact['email']); ?>

</p>
<?php endif; ?> 

<?php if(isset($contact['address'])): ?> 
<p>
Địa chỉ: <?php echo e($contact['address']); ?>

</p>
<?php endif; ?> 

<?php if(isset($contact['phone'])): ?> 
<p>
Điện thoại: <?php echo e($contact['phone']); ?>

</p>
<?php endif; ?> 

<?php if(isset($contact['subject'])): ?> 
<p>
Chủ đề: <?php echo e($contact['subject']); ?>

</p>
<?php endif; ?> 

<?php if(isset($contact['msg'])): ?> 
<p>
Nội dung: <?php echo e($contact['msg']); ?>

</p>
<?php endif; ?> 