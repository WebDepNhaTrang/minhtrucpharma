<?php $__env->startSection('title', 'Hoạt Động Nổi Bật'); ?>
<?php $__env->startSection('description', setting('site.description')); ?>

<?php $__env->startSection('fb_url', url('/')); ?>
<?php $__env->startSection('fb_type', 'website'); ?>
<?php $__env->startSection('fb_title', 'Hoạt Động Nổi Bật - Minh Trúc Pharma'); ?>
<?php $__env->startSection('fb_des', setting('site.description')); ?>
<?php $__env->startSection('fb_img', ''); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
        <!-- inner page banner -->
        <div class="dez-bnr-inr overlay-black-middle" style="background-image:url(<?php echo e(Voyager::image(setting('news.background'))); ?>);">
            <div class="container">
                <div class="dez-bnr-inr-entry">
                    <h1 class="text-white"><?php echo e(setting('news.title')); ?></h1>
                </div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- Breadcrumb row -->
        <div class="breadcrumb-row">
            <div class="container">
                <ul class="list-inline">
                    <li><a href="<?php echo e(route('frontend.pages.home')); ?>">Trang Chủ</a></li>
                    <li>Hoạt Động Nổi Bật</li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb row END -->
        <?php
            $posts = getPostByCategory('*', 1, 'created_at', 'desc', setting('news.paginate'));
        ?>
        <?php if($posts->count()>0): ?>
        <div class="content-area">
            <div class="container">
                <div class="row">
                    <!-- blog grid -->
                    <div id="masonry" class="dez-blog-grid-3">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post card-container col-lg-4 col-md-6 col-sm-6 col-xs-12">
                            <div class="blog-post blog-grid date-style-2">
                                <div class="dez-post-media dez-img-effect zoom-slow"> <a href="<?php echo e(route('frontend.pages.news-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>"><img src="<?php echo e(Voyager::image($v->image)); ?>" alt="<?php echo e($v->title); ?>"></a> </div>
                                <div class="dez-post-info">
                                    <div class="dez-post-title ">
                                        <h3 class="post-title"><a href="<?php echo e(route('frontend.pages.news-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>"><?php echo e($v->title); ?></a></h3>
                                    </div>
                                    <div class="dez-post-meta ">
                                        <ul>
                                            <li class="post-date"> <i class="fa fa-calendar"></i><strong><?php echo e($v->created_at->format('d-M')); ?></strong> <span> <?php echo e($v->created_at->format('Y')); ?></span> </li>
                                            <li class="post-author"><i class="fa fa-user"></i>Đăng bởi <a href="<?php echo e(route('frontend.pages.home')); ?>">Minh Trúc Pharma</a> </li>
                                        </ul>
                                    </div>
                                    <div class="dez-post-text">
                                        <p class="excerpt"><?php echo e(shorten_text($v->excerpt, 200, '...', true)); ?></p>
                                    </div>
                                    <div class="dez-post-readmore"> <a href="<?php echo e(route('frontend.pages.news-detail', ['slug' => $v->slug, 'id' => $v->id])); ?>" title="Xem Thêm" rel="bookmark" class="site-button-link">Xem Thêm<i class="fa fa-angle-double-right"></i></a> </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- blog grid END -->
                    <!-- Pagination -->
                    <div class="pagination-bx col-lg-12 clearfix ">
                        <?php echo e($posts->links()); ?>

                    </div>
                    <!-- Pagination END -->
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme-default.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>