<?php
    // echo "<pre>";
    // print_r($product);
    // echo "</pre>";
    // die();
?>


<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('description', $product->name); ?>

<?php $__env->startSection('fb_url', route('frontend.pages.product-detail', ['slug' => $product->slug, 'id' => $product->id])); ?>
<?php $__env->startSection('fb_type', 'website'); ?>
<?php $__env->startSection('fb_title', $product->name); ?>
<?php $__env->startSection('fb_des', $product->name); ?>
<?php $__env->startSection('fb_img', Voyager::image($product->image)); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area">
    <!-- Product details -->
    <div class="container woo-entry">
        <div class="row m-b30">
            <div class="blog-post blog-md date-style-2">
                <div class="col-md-4 col-sm-4 m-b30"> <a href="#"><img src="<?php echo e(Voyager::image($product->image)); ?>" alt="<?php echo e($product->name); ?>"></a> </div>
                <div class="col-md-8 col-sm-8">
                    <div class="dez-post-title ">
                        <h3 class="post-title"><a href="#"><?php echo e($product->name); ?></a></h3>
                    </div>
                    <h2 class="m-tb10"><?php echo e(number_format($product->price, 0, '', '.')); ?> VNĐ</h2>
                    <div class="dez-post-text">
                        <?php echo $product->excerpt; ?>

                    </div>
                    <table class="table table-bordered" >
                        <tr>
                            <td>Giá</td>
                            <td><?php echo e(number_format($product->price, 0, '', '.')); ?> VNĐ</td>
                        </tr>
                        <tr>
                            <td>Trạng Thái</td>
                            <td>Có Sẵn</td>
                        </tr>
                        <tr>
                            <td>Đánh Giá</td>
                            <td><span class="rating-bx"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></span> </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="dez-tabs border-top product-description bg-tabs">
                    <ul class="nav nav-tabs ">
                        <li class="active"><a data-toggle="tab" href="#web-design-1"><i class="fa fa-globe"></i> Mô Tả</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="web-design-1" class="tab-pane active">
                            <?php echo $product->body; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Product details -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme-default.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>