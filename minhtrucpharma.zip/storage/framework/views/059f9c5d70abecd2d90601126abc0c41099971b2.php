<ul class=" nav navbar-nav">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="<?php echo e(Route::currentRouteName() == $menu_item->route ? 'active' : ''); ?>">
            <?php if($menu_item->children && count($menu_item->children) > 0): ?>
                <a href="javascript:;"><?php echo e($menu_item->title); ?><i class="fa fa-chevron-down"></i></a>
                <ul class="sub-menu">
                    <?php $__currentLoopData = $menu_item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($menu_child->link()); ?>"><?php echo e($menu_child->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <a href="<?php echo e($menu_item->link()); ?>"><?php echo e($menu_item->title); ?></a>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>