<!-- JavaScript  files ========================================= -->
<script   src="{{ asset('js/jquery.min.js') }}"></script>
<!-- jquery.min js -->
<script   src="{{ asset('js/bootstrap.min.js') }}"></script>
<!-- bootstrap.min js -->
<script   src="{{ asset('js/bootstrap-select.min.js') }}"></script>
<!-- Form js -->
<script   src="{{ asset('js/jquery.bootstrap-touchspin.js') }}"></script>
<!-- Form js -->
<script   src="{{ asset('js/magnific-popup.js') }}"></script>
<!-- magnific-popup js -->
<script   src="{{ asset('js/waypoints-min.js') }}"></script>
<!-- waypoints js -->
<script   src="{{ asset('js/counterup.min.js') }}"></script>
<!-- counterup js -->
<script  src="{{ asset('js/imagesloaded.js') }}"></script>
<!-- masonry  -->
<script  src="{{ asset('js/masonry-3.1.4.js') }}"></script>
<!-- masonry  -->
<script  src="{{ asset('js/masonry.filter.js') }}"></script>
<!-- masonry  -->
<script   src="{{ asset('js/owl.carousel.js') }}"></script>
<!-- OWL  Slider  -->
<script   src="{{ asset('js/custom.js') }}"></script>
<!-- custom fuctions  -->
<script   src="{{ asset('js/dz.carousel.js') }}"></script>
<!-- sortcode fuctions  -->

<!-- switcher fuctions  -->
<!-- <script   src="{{ asset('js/dz.ajax.js') }}"></script> -->
<!-- contact-us js -->
<!-- revolution JS FILES -->
<script  src="{{ asset('plugins/revolution/revolution/js/jquery.themepunch.tools.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js') }}"></script>
<!-- Slider revolution 5.0 Extensions  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.actions.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.carousel.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.kenburn.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.migration.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.navigation.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.parallax.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
<script  src="{{ asset('plugins/revolution/revolution/js/extensions/revolution.extension.video.min.js') }}"></script>
<script   src="{{ asset('js/rev.slider.js') }}"></script>
<script >
jQuery(document).ready(function() {
	'use strict';
	dz_rev_slider_3();
});	/*ready*/
</script>