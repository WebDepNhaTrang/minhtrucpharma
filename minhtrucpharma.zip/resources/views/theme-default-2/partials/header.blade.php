<h1>Header Section</h1>

<div class="menu">
    <p>Menu:</p>
    {{ menu('frontend', 'theme-default.partials.main-menu') }}
</div>